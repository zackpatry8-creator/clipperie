export default function Home() {
  return (
    <main className="flex min-h-dvh items-center justify-center p-6">
      <div className="flex aspect-[9/16] w-full max-w-xs flex-col justify-between border-4 border-encre bg-creme p-6 shadow-[8px_8px_0_0_#14213d]">
        <p className="text-sm font-medium">Clipperie</p>
        <div>
          <h1 className="font-titre text-5xl font-black leading-[1.05]">
            Ça arrive.
          </h1>
          <p className="mt-4 text-lg leading-snug">
            Un live de deux heures devient trente clips verticaux.
          </p>
        </div>
        <p className="bg-brule px-3 py-2 text-sm font-medium text-creme">
          Ouverture très bientôt
        </p>
      </div>
    </main>
  );
}
